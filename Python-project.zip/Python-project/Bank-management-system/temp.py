import random
print(random.randint(10000000, 99999999))