import pymongo

# Connect to MongoDB Atlas cluster
myclient = pymongo.MongoClient("mongodb+srv://rahulverma9559:2JEc0XwXpgfEU8TE@cluster0.7sa8r47.mongodb.net/test?retryWrites=true&w=majority")
mydb = myclient["test"]  # Specify the database name

def db_query():
    # Create 'customers' collection (equivalent to table in relational databases)
    customers_collection = mydb['customers']

    # Create indexes if needed
    customers_collection.create_index([("username", 1)], unique=True)  # Ensure username is unique

    # Insert sample customer data (optional)
    customers_data = [
        {
            "username": "rverma",
            "password": "password12",
            "name": "rverma Doe",
            "age": 29,
            "city": "New York",
            "balance": 5000,
            "account_number": 123456789,
            "status": True
        },
        {
            "username": "jane_smith",
            "password": "securepwd",
            "name": "Jane Smith",
            "age": 25,
            "city": "Los Angeles",
            "balance": 3000,
            "account_number": 987654321,
            "status": True
        }
    ]
    # Insert sample data into the 'customers' collection
    customers_collection.insert_many(customers_data)
print("Database created successfully!")

if __name__ == "__main__":
    db_query()
