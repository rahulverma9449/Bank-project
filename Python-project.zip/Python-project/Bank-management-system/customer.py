from database import db_query, mydb  # Assuming these are imported correctly

class Customer:

    def __init__(self, username, password, name, age, city, account_number):
        self.username = username
        self.password = password
        self.name = name
        self.age = age
        self.city = city
        self.account_number = account_number

    def create_user(self):
        try:
            # Use placeholder values to prevent SQL injection
            sql = "INSERT INTO customers (username, password, name, age, city, balance, account_number, status) VALUES (%s, %s, %s, %s, %s, %s, %s, %s)"
            values = (self.username, self.password, self.name, self.age, self.city, 0, self.account_number, 1)
            
            cursor = mydb.cursor()
            cursor.execute(sql, values)
            mydb.commit()
            print("Customer created successfully!")
        except Exception as e:
            print(f"Error creating customer: {str(e)}")
            mydb.rollback()
        finally:
            cursor.close()  # Close the cursor after execution

# Example usage:
if __name__ == "__main__":
    # Create a new Customer object and insert into the database
    customer = Customer("john_doe", "password123", "John Doe", 30, "New York", 123456789)
    customer.create_user()
