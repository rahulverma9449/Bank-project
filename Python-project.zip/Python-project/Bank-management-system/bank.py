from database import db_query  # Import MongoDB database functions
from datetime import datetime

class Bank:
    def __init__(self, username, account_number):
        self.username = username
        self.account_number = account_number

    def create_transaction_collection(self):
        # Create a collection for transactions specific to the user
        transaction_collection_name = f"{self.username}_transaction"
        db_query.create_collection(transaction_collection_name)

    def balance_enquiry(self):
        # Retrieve balance from customer document in MongoDB
        customer = db_query.find_one({"username": self.username})
        if customer:
            balance = customer.get("balance", 0)
            print(f"{self.username} Balance is {balance}")
        else:
            print(f"Customer '{self.username}' not found.")

    def deposit(self, amount):
        # Update customer document with deposited amount and record transaction
        customer = db_query.find_one({"username": self.username})
        if customer:
            current_balance = customer.get("balance", 0)
            new_balance = current_balance + amount
            db_query.update_one(
                {"username": self.username},
                {"$set": {"balance": new_balance}}
            )
            self.balance_enquiry()
            transaction_data = {
                "timedate": datetime.now(),
                "account_number": self.account_number,
                "remarks": "Amount Deposit",
                "amount": amount
            }
            db_query[f"{self.username}_transaction"].insert_one(transaction_data)
            print(f"{self.username} Amount successfully deposited into Account {self.account_number}")
        else:
            print(f"Customer '{self.username}' not found.")

    def withdraw(self, amount):
        # Withdraw amount from customer balance and record transaction
        customer = db_query.find_one({"username": self.username})
        if customer:
            current_balance = customer.get("balance", 0)
            if amount > current_balance:
                print("Insufficient Balance. Please deposit money.")
            else:
                new_balance = current_balance - amount
                db_query.update_one(
                    {"username": self.username},
                    {"$set": {"balance": new_balance}}
                )
                self.balance_enquiry()
                transaction_data = {
                    "timedate": datetime.now(),
                    "account_number": self.account_number,
                    "remarks": "Amount Withdraw",
                    "amount": amount
                }
                db_query[f"{self.username}_transaction"].insert_one(transaction_data)
                print(f"{self.username} Amount successfully withdrawn from Account {self.account_number}")
        else:
            print(f"Customer '{self.username}' not found.")

    def fund_transfer(self, receive_account_number, amount):
        # Transfer funds between accounts and record transactions
        sender = db_query.find_one({"username": self.username})
        receiver = db_query.find_one({"account_number": receive_account_number})
        if sender and receiver:
            sender_balance = sender.get("balance", 0)
            receiver_balance = receiver.get("balance", 0)
            if amount > sender_balance:
                print("Insufficient Balance. Please deposit money.")
            else:
                new_sender_balance = sender_balance - amount
                new_receiver_balance = receiver_balance + amount
                db_query.update_one(
                    {"username": self.username},
                    {"$set": {"balance": new_sender_balance}}
                )
                db_query.update_one(
                    {"account_number": receive_account_number},
                    {"$set": {"balance": new_receiver_balance}}
                )
                self.balance_enquiry()
                sender_transaction_data = {
                    "timedate": datetime.now(),
                    "account_number": self.account_number,
                    "remarks": f"Fund Transfer -> {receive_account_number}",
                    "amount": amount
                }
                receiver_transaction_data = {
                    "timedate": datetime.now(),
                    "account_number": receive_account_number,
                    "remarks": f"Fund Transfer From {self.account_number}",
                    "amount": amount
                }
                db_query[f"{self.username}_transaction"].insert_one(sender_transaction_data)
                db_query[f"{receiver['username']}_transaction"].insert_one(receiver_transaction_data)
                print(f"{self.username} Amount successfully transferred to Account {receive_account_number}")
        else:
            print("Sender or receiver account not found.")

# Example usage:
if __name__ == "__main__":
    # Create a Bank object and perform banking operations
    bank = Bank("john_doe", 123456789)
    bank.deposit(1000)
    bank.withdraw(500)
    bank.fund_transfer(987654321, 300)
