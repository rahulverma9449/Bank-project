from register import SignUp, SignIn
from bank import Bank

print("Welcome to Rahul Banking Project")

# User Authentication Loop
user = None
while True:
    try:
        choice = int(input("1. SignUp\n"
                           "2. SignIn\n"
                           "Choose an option: "))
        if choice == 1:
            SignUp()
        elif choice == 2:
            user = SignIn()
            if user:
                break  # Exit loop if SignIn successful
        else:
            print("Please enter a valid option (1 or 2)")

    except ValueError:
        print("Invalid input. Please enter a valid option (1 or 2)")

# Banking Services Loop
while user:
    print(f"Welcome {user.capitalize()}! Choose Your Banking Service\n")
    try:
        facility = int(input("1. Balance Enquiry\n"
                             "2. Cash Deposit\n"
                             "3. Cash Withdraw\n"
                             "4. Fund Transfer\n"
                             "Choose a service (1-4): "))

        bobj = Bank(user)  # Initialize Bank object for the user

        if facility == 1:
            bobj.balance_enquiry()
        elif facility == 2:
            amount = int(input("Enter Amount to Deposit: "))
            bobj.deposit(amount)
        elif facility == 3:
            amount = int(input("Enter Amount to Withdraw: "))
            bobj.withdraw(amount)
        elif facility == 4:
            receiver = int(input("Enter Receiver Account Number: "))
            amount = int(input("Enter Money to Transfer: "))
            bobj.fund_transfer(receiver, amount)
        else:
            print("Please enter a valid service option (1-4)")

    except ValueError:
        print("Invalid input. Please enter a valid number.")

    # Prompt user to continue banking services
    choice = input("Do you want to continue (yes/no)? ").lower()
    if choice != 'yes':
        break

print("Thank you for using Mohit Banking Project!")
